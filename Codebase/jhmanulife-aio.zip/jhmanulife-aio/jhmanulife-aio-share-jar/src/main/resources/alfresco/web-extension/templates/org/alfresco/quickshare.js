function main()
{
   // Make the shareid available in token resolution when the components are bound into the page
   // I.e. <param>{shareid}</param>
   var shareId = page.url.args.id;
   if (shareId.indexOf("?") !== -1)
   {
      shareId = shareId.substring(0, shareId.indexOf("?"));
   }
   context.attributes.shareid = shareId;
   // Check of the shareId exists
   var result = remote.connect("alfresco-noauth").get("/api/internal/shared/node/" + encodeURIComponent(shareId) + "/metadata");
   model.outcome = result.status == 200 ? "" : "error";
   
   var typeParam = page.url.args.type;
   if(typeParam != null && typeParam !== 'undefined' ){
		result = eval("(" + result.response + ")");
	    previewupdateResult = remote.connect("alfresco-noauth").get("/manulife/previewupdate?nodeRef=" + result.nodeRef + "&type="+typeParam);
	    previewupdateResult = previewupdateResult.status == 200 ? "" : "error"; 
   }
}

main();
