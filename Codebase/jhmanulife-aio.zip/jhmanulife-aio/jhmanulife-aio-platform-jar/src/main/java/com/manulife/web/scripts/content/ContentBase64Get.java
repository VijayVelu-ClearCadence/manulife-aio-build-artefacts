package com.manulife.web.scripts.content;

import java.io.BufferedInputStream;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import org.alfresco.model.ContentModel;
import org.alfresco.service.cmr.repository.ContentReader;
import org.alfresco.service.cmr.repository.ContentService;
import org.alfresco.service.cmr.repository.NodeRef;
import org.apache.commons.io.IOUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.extensions.webscripts.Cache;
import org.springframework.extensions.webscripts.DeclarativeWebScript;
import org.springframework.extensions.webscripts.Status;
import org.springframework.extensions.webscripts.WebScriptRequest;
import org.springframework.security.crypto.codec.Base64;

import com.manulife.constants.BusinessConstants;

public class ContentBase64Get extends DeclarativeWebScript {

	private static Log logger = LogFactory.getLog(ContentBase64Get.class);

	protected Properties properties;
	private ContentService contentService;

	public Properties getProperties() {
		return properties;
	}

	public void setProperties(Properties properties) {
		this.properties = properties;
	}

	public ContentService getContentService() {
		return contentService;
	}

	public void setContentService(ContentService contentService) {
		this.contentService = contentService;
	}

	@Override
	protected Map<String, Object> executeImpl(WebScriptRequest req, Status status, Cache cache) {

		Map<String, Object> model = new HashMap<>();
		String nodeInBase64 = "";

		try {

			String nodeRefParam = req.getParameter(BusinessConstants.PARAMETER_NODEREF);
			NodeRef docNodeRef = new NodeRef(nodeRefParam);

			ContentReader contentReader = contentService.getReader(docNodeRef, ContentModel.PROP_CONTENT);
			InputStream nodeInputStream = new BufferedInputStream(contentReader.getContentInputStream(), 4096);

			byte[] nodeBytes = IOUtils.toByteArray(nodeInputStream);
			nodeInBase64 = new String(Base64.encode(nodeBytes));

			model.put("documentBase64", nodeInBase64);

		} catch (Exception e) {
			logger.error(e.getMessage(), e);
			model.put(BusinessConstants.ERROR, e.getMessage());
		}

		return model;
	}

}
