package com.manulife.exceptions;

public class MissingPropertiesException extends Exception {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -569185321135445642L;

	public MissingPropertiesException(String msg) {
		super(msg);
	}
}
