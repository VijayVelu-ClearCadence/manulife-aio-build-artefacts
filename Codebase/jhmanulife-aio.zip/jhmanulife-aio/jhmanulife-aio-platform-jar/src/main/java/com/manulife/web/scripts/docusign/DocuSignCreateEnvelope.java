package com.manulife.web.scripts.docusign;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import javax.net.ssl.HttpsURLConnection;

import org.alfresco.model.ContentModel;
import org.alfresco.service.cmr.repository.ContentReader;
import org.alfresco.service.cmr.repository.ContentService;
import org.alfresco.service.cmr.repository.NodeRef;
import org.alfresco.service.cmr.repository.NodeService;
import org.apache.commons.io.IOUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.json.JSONObject;
import org.springframework.extensions.surf.util.Content;
import org.springframework.extensions.webscripts.Cache;
import org.springframework.extensions.webscripts.DeclarativeWebScript;
import org.springframework.extensions.webscripts.Status;
import org.springframework.extensions.webscripts.WebScriptException;
import org.springframework.extensions.webscripts.WebScriptRequest;
import org.springframework.security.crypto.codec.Base64;

import com.manulife.constants.BusinessConstants;
import com.manulife.exceptions.MissingPropertiesException;

/**
 * 
 * @author Vijay Velu- Dt. 18-Feb 2020.
 *
 */
public class DocuSignCreateEnvelope extends DeclarativeWebScript {

	private static Log logger = LogFactory.getLog(DocuSignCreateEnvelope.class);

	protected Properties properties;
	private ContentService contentService;
	private NodeService nodeService;

	public Properties getProperties() {
		return properties;
	}

	public void setProperties(Properties properties) {
		this.properties = properties;
	}

	public ContentService getContentService() {
		return contentService;
	}

	public void setContentService(ContentService contentService) {
		this.contentService = contentService;
	}

	public NodeService getNodeService() {
		return nodeService;
	}

	public void setNodeService(NodeService nodeService) {
		this.nodeService = nodeService;
	}

	@Override
	protected Map<String, Object> executeImpl(WebScriptRequest req, Status status, Cache cache) {

		Map<String, Object> model = new HashMap<>();
		String nodeInBase64 = "";

		try {

			String nodeRefParam = req.getParameter(BusinessConstants.PARAMETER_NODEREF);
			Content c = req.getContent();
			if (c == null) {
				throw new WebScriptException(Status.STATUS_BAD_REQUEST, "Missing POST body.");
			}

			JSONObject jsonReqBody = new JSONObject(c.getContent());
			logger.debug(" ::: jsonReqBody.toString() ::: " + jsonReqBody.toString());

			if (nodeRefParam == null) {
				throw new WebScriptException(Status.STATUS_BAD_REQUEST,
						"Webscript is missing the \'nodeRef\' parameter.");
			}

			NodeRef docNodeRef = new NodeRef(nodeRefParam);

			if (!nodeService.exists(docNodeRef)) {
				throw new WebScriptException("No node found for id:" + nodeRefParam);
			}

			String documentName = nodeService.getProperty(docNodeRef, ContentModel.PROP_NAME).toString();
			logger.debug(" ::: documentName ::: " + documentName);

			ContentReader contentReader = contentService.getReader(docNodeRef, ContentModel.PROP_CONTENT);
			InputStream nodeInputStream = new BufferedInputStream(contentReader.getContentInputStream(), 4096);

			byte[] nodeBytes = IOUtils.toByteArray(nodeInputStream);
			nodeInBase64 = new String(Base64.encode(nodeBytes));

			// building documents object for DocuSign create envelope request
			List<JSONObject> documentsAttribute = new ArrayList<>();

			JSONObject doc = new JSONObject();
			doc.put("documentBase64", nodeInBase64);
			doc.put("name", documentName);
			doc.put("documentId", "1");

			documentsAttribute.add(doc);

			jsonReqBody.put("documents", documentsAttribute);

			// DocuSign AccountId used for creating envelopes.
			String docuSignAccountId = (String) properties.get("docusign.accountId");
			logger.debug(" ::: docuSignAccountId ::: " + docuSignAccountId);

			String docuSignRESTBaseURL = (String) properties.get("docusign.rest.baseurl");
			logger.debug(" ::: docuSignRESTBaseURL ::: " + docuSignRESTBaseURL);

			if (docuSignAccountId == null || docuSignAccountId.isEmpty()) {
				throw new MissingPropertiesException(
						"Invalid \'docuSignAccountId\' property set in alfresco-global.properties.");
			}

			if (docuSignRESTBaseURL == null || docuSignRESTBaseURL.isEmpty()) {
				throw new MissingPropertiesException(
						"Invalid \'docuSignRESTBaseURL\' property set in alfresco-global.properties.");
			}

			String createEnvelopeURL = docuSignRESTBaseURL + "accounts/" + docuSignAccountId + "/envelopes";
			logger.debug(" ::: createEnvelopeURL ::: " + createEnvelopeURL);

			System.setProperty("https.protocols", "TLSv1.2");
			URL url = new URL(createEnvelopeURL);
			HttpsURLConnection conn = (HttpsURLConnection) url.openConnection();

			String docuSignAccessToken = jsonReqBody.getString("docuSignAccessToken");
			conn.setRequestProperty("Authorization", "Bearer " + docuSignAccessToken);

			conn.setRequestProperty("Content-Type", "application/json");
			conn.setRequestMethod("POST");
			conn.setRequestProperty("Accept", "application/json");

			conn.setDoOutput(true);

			OutputStream os = conn.getOutputStream();
			byte[] input = jsonReqBody.toString().getBytes("utf-8");
			os.write(input, 0, input.length);
			os.close();

			conn.connect();

			BufferedReader in = new BufferedReader(new InputStreamReader(conn.getInputStream()));
			String output;

			StringBuffer response = new StringBuffer();
			while ((output = in.readLine()) != null) {
				response.append(output);
			}

			in.close();
			// printing result from response
			logger.debug("Response:-" + response.toString());

			model.put("response", response.toString());

		} catch (Exception e) {
			logger.error(e.getMessage(), e);
			model.put(BusinessConstants.ERROR, e.getMessage());
		}

		return model;
	}

}
