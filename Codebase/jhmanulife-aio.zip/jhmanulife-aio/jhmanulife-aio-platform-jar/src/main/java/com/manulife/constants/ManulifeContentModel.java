package com.manulife.constants;

import org.alfresco.service.namespace.QName;

public final class ManulifeContentModel {
	private ManulifeContentModel() {
	}

	public static final String MANULIFE_CONTENT_MODEL_NS = "http://www.manulife.org/model/content/1.0";
	public static final QName PROP_HAS_AGENT_VIEWED = QName.createQName(MANULIFE_CONTENT_MODEL_NS, "hasAgentViewed");
	public static final QName PROP_HAS_CUSTOMER_VIEWED = QName.createQName(MANULIFE_CONTENT_MODEL_NS,
			"hasCustomerViewed");
	public static final QName ASPECT_AGENT_VIEWED = QName.createQName(MANULIFE_CONTENT_MODEL_NS, "agentViewed");
	public static final QName ASPECT_CUSTOMER_VIEWED = QName.createQName(MANULIFE_CONTENT_MODEL_NS, "customerViewed");
	public static final QName PROP_AGENT_LINK = QName.createQName(MANULIFE_CONTENT_MODEL_NS, "agentLink");
	public static final QName PROP_CUSTOMER_LINK = QName.createQName(MANULIFE_CONTENT_MODEL_NS, "customerLink");
	public static final QName PROP_AGENT_EMAIL = QName.createQName(MANULIFE_CONTENT_MODEL_NS, "agentEmail");
	public static final QName PROP_CUSTOMER_EMAIL = QName.createQName(MANULIFE_CONTENT_MODEL_NS, "customerEmail");
	public static final QName TYPE_CONTENT_POLICYTYPE = QName.createQName(MANULIFE_CONTENT_MODEL_NS, "policyType");

}
