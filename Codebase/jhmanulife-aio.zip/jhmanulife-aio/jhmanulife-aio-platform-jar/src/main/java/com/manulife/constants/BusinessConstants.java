package com.manulife.constants;

public final class BusinessConstants {
	private BusinessConstants() {
	}

	public static final String PARAMETER_NODEREF = "nodeRef";
	public static final String PARAMETER_TYPE = "type";
	public static final String PARAMETER_TYPE_AGENT = "agent";
	public static final String PARAMETER_TYPE_CUSTOMER = "customer";
	public static final String PREVIEW_STATUS_ALL_VIEWED = "allViewed";
	public static final String PREVIEW_STATUS = "previewStatus";
	
	public static final String ERROR = "error";
	public static final String ERROR_MESSAGE = "Customer or Agent value not found";
}
