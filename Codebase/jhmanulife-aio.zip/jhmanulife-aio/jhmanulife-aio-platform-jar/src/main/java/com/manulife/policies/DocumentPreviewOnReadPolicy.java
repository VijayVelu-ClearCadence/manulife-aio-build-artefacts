/**
 * Copyright (C) 2017 Alfresco Software Limited.
 * <p/>
 * This file is part of the Alfresco SDK project.
 * <p/>
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * <p/>
 * http://www.apache.org/licenses/LICENSE-2.0
 * <p/>
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.manulife.policies;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

import org.alfresco.repo.content.ContentServicePolicies;
import org.alfresco.repo.policy.Behaviour;
import org.alfresco.repo.policy.JavaBehaviour;
import org.alfresco.repo.policy.PolicyComponent;
import org.alfresco.repo.security.authentication.AuthenticationUtil;
import org.alfresco.repo.security.authentication.AuthenticationUtil.RunAsWork;
import org.alfresco.repo.transaction.RetryingTransactionHelper;
import org.alfresco.repo.transaction.RetryingTransactionHelper.RetryingTransactionCallback;
import org.alfresco.service.cmr.repository.NodeRef;
import org.alfresco.service.cmr.repository.NodeService;
import org.alfresco.service.namespace.QName;
import org.alfresco.service.transaction.TransactionService;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.manulife.constants.ManulifeContentModel;

public class DocumentPreviewOnReadPolicy {
	private static Log logger = LogFactory.getLog(DocumentPreviewOnReadPolicy.class);

	private PolicyComponent eventManager;

	public void setPolicyComponent(PolicyComponent policyComponent) {
		this.eventManager = policyComponent;
	}

	private TransactionService transactionService;

	public void setTransactionService(TransactionService transactionService) {
		this.transactionService = transactionService;
	}

	public void registerEventHandlers() {
		eventManager.bindClassBehaviour(ContentServicePolicies.OnContentReadPolicy.QNAME,
				ManulifeContentModel.TYPE_CONTENT_POLICYTYPE,
				new JavaBehaviour(this, "onContentRead", Behaviour.NotificationFrequency.EVERY_EVENT));

	}

	public void onContentRead(NodeRef nodeRef) {
		logger.info("DocumentPreviewOnReadPolicy,  NodeRef : " + nodeRef);

		// TODO: write a condition to decide shared link is viewed by agent or customer
		boolean hasAspect = nodeService.hasAspect(nodeRef, ManulifeContentModel.ASPECT_CUSTOMER_VIEWED);
		if (!hasAspect) {
			addAspectTransction(nodeRef, ManulifeContentModel.ASPECT_CUSTOMER_VIEWED,
					ManulifeContentModel.PROP_HAS_CUSTOMER_VIEWED);
		}

		hasAspect = nodeService.hasAspect(nodeRef, ManulifeContentModel.ASPECT_AGENT_VIEWED);
		if (!hasAspect) {
			addAspectTransction(nodeRef, ManulifeContentModel.ASPECT_AGENT_VIEWED,
					ManulifeContentModel.PROP_HAS_AGENT_VIEWED);
		}
	}

	private NodeService nodeService;

	public void setNodeService(NodeService nodeService) {
		this.nodeService = nodeService;
	}

	private void addAspectTransction(NodeRef nodeRef, QName aspectQName, QName propertyQName) {
		AuthenticationUtil.runAsSystem(new RunAsWork<Void>() {

			public Void doWork() throws Exception {

				RetryingTransactionCallback<Void> callback = new RetryingTransactionCallback<Void>() {

					@Override
					public Void execute() throws Throwable {

						Map<QName, Serializable> aspectProperties = new HashMap<>();
						aspectProperties.put(propertyQName, true);

						nodeService.addAspect(nodeRef, aspectQName, aspectProperties);
						return null;
					}
				};

				try {
					RetryingTransactionHelper txnHelper = transactionService.getRetryingTransactionHelper();
					txnHelper.doInTransaction(callback, false, true);
				} catch (Throwable e) {
					e.printStackTrace();
				}

				return null;

			}
		});
	}

}