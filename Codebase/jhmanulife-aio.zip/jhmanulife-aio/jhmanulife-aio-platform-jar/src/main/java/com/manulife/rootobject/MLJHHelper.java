package com.manulife.rootobject;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;

import org.alfresco.repo.processor.BaseProcessorExtension;
import org.alfresco.service.cmr.quickshare.QuickShareDTO;
import org.alfresco.service.cmr.quickshare.QuickShareService;
import org.alfresco.service.cmr.repository.NodeRef;
import org.apache.chemistry.opencmis.commons.impl.json.JSONObject;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.pdfbox.util.PDFMergerUtility;
import org.springframework.extensions.surf.util.InputStreamContent;
import org.springframework.extensions.webscripts.servlet.FormData.FormField;

import com.manulife.exceptions.MissingPropertiesException;

/**
 * 
 * @author Vijay Velu- Dt. 06 Jan 2020.
 * 
 *
 */
public class MLJHHelper extends BaseProcessorExtension {
	private static Log logger = LogFactory.getLog(MLJHHelper.class);

	protected Properties properties;

	protected QuickShareService quickShareService;

	public Properties getProperties() {
		return properties;
	}

	public void setProperties(Properties properties) {
		this.properties = properties;
	}

	public QuickShareService getQuickShareService() {
		return quickShareService;
	}

	public void setQuickShareService(QuickShareService quickShareService) {
		this.quickShareService = quickShareService;
	}

	public JSONObject mergeFieldDocs(FormField[] formFieldArray) throws IOException {

		logger.debug(" ::: Start mergeFiles method ::: ");

		JSONObject jsonOb = new JSONObject();
		String mergedFileName = null;

		List<FormField> fyiFields = new ArrayList<>();
		List<FormField> contrecFields = new ArrayList<>();
		List<FormField> contractPDRDefinedFields = new ArrayList<>();
		List<FormField> contractPDRUnDefinedFields = new ArrayList<>();
		List<FormField> otherFields = new ArrayList<>();

		List<FormField> allFields = new ArrayList<>();

		try {

			String tempFolderPath = properties.getProperty("temp.folder.path");

			if (tempFolderPath == null || tempFolderPath.isEmpty()) {
				throw new MissingPropertiesException(
						"temp.folder.path is not set or has an invalid value in the alfresco-global.properties file.");
			}

			PDFMergerUtility pdfMerger = new PDFMergerUtility();

			for (FormField formField : formFieldArray) {

				String fileName = formField.getFilename();

				// For setting the mergedFileName
				if (mergedFileName == null) {

					mergedFileName = fileName;
					logger.debug(" ::: original fileName ::: " + mergedFileName);

					if (mergedFileName.lastIndexOf('_') != -1) {
						mergedFileName = mergedFileName.substring(0, mergedFileName.lastIndexOf('_')) + ".pdf";
					}
					logger.debug(" ::: new mergedFileName ::: " + mergedFileName);
				}

				// Controlling the order of merge of files
				if (fileName.contains("_FYI")) {
					fyiFields.add(formField);
				} else if (fileName.contains("_CONTREC")) {
					contrecFields.add(formField);
				}
				// Defined ContractPDRs
				else if (fileName.contains("_PROPUNSGN") || fileName.contains("_AMENDMENT")
						|| fileName.contains("_CODBK") || fileName.contains("_MMATIC")
						|| fileName.contains("_AGENTRPT")) {
					contractPDRDefinedFields.add(formField);
				}
				// Undefined contract PDRs
				else if (fileName.contains("_CONTRACTPDR")) {
					contractPDRUnDefinedFields.add(formField);
				}
				// Other files
				else {
					otherFields.add(formField);
				}

				// Add file content as InputStream
				// pdfMerger.addSource(formField.getInputStream());

			}

			String outputFilePath = tempFolderPath + mergedFileName;

			allFields.addAll(fyiFields);
			allFields.addAll(contrecFields);
			allFields.addAll(contractPDRDefinedFields);
			allFields.addAll(contractPDRUnDefinedFields);
			allFields.addAll(otherFields);

			for (Iterator<FormField> iterator = allFields.iterator(); iterator.hasNext();) {

				FormField fField = iterator.next();
				logger.debug(" ::: Sorted fField.getFilename() ::: " + fField.getFilename());

				pdfMerger.addSource(fField.getInputStream());

			}

			pdfMerger.setDestinationFileName(outputFilePath);
			pdfMerger.mergeDocuments();

			InputStream stream = new FileInputStream(outputFilePath);

			String mimeType = "application/pdf";

			InputStreamContent inputStreamContent = new InputStreamContent(stream, mimeType, null);

			jsonOb.put("fileName", mergedFileName);
			jsonOb.put("content", inputStreamContent);
			jsonOb.put("mimeType", mimeType);

		} catch (IOException ioe) {
			ioe.printStackTrace();
			logger.error(ioe.getMessage(), ioe);
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage(), e);
		}

		logger.debug(" ::: End mergeFiles method ::: ");

		return jsonOb;
	}

	public String shareContent(NodeRef nodeRef) {

		String quickshareId = null;

		try {

			QuickShareDTO dto = quickShareService.shareContent(nodeRef);
			quickshareId = dto.getId();
			logger.debug(" ::: dto.getId() ::: " + dto.getId());

		} catch (Exception e) {
			logger.error(e.getMessage(), e);
		}

		return quickshareId;
	}

}
