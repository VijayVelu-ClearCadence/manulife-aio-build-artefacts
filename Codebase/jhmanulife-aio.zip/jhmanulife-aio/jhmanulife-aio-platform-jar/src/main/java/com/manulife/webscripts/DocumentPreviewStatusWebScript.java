/**
 * Copyright (C) 2017 Alfresco Software Limited.
 * <p/>
 * This file is part of the Alfresco SDK project.
 * <p/>
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * <p/>
 * http://www.apache.org/licenses/LICENSE-2.0
 * <p/>
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.manulife.webscripts;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

import org.alfresco.service.cmr.repository.NodeRef;
import org.alfresco.service.cmr.repository.NodeService;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.extensions.webscripts.Cache;
import org.springframework.extensions.webscripts.DeclarativeWebScript;
import org.springframework.extensions.webscripts.Status;
import org.springframework.extensions.webscripts.WebScriptRequest;

import com.manulife.constants.BusinessConstants;
import com.manulife.constants.ManulifeContentModel;

public class DocumentPreviewStatusWebScript extends DeclarativeWebScript {
	private static Log logger = LogFactory.getLog(DocumentPreviewStatusWebScript.class);
	private NodeService nodeService;

	@Override
	protected Map<String, Object> executeImpl(WebScriptRequest req, Status status, Cache cache) {
		
		logger.debug(" ::: Start DocumentPreviewStatusWebScript.executeImpl method ::: ");
		
		Map<String, Object> model = new HashMap<>();
		String nodeRefParam = req.getParameter(BusinessConstants.PARAMETER_NODEREF);
		logger.debug("PreviewStatusWebScript, parameter id = " + nodeRefParam);
		
		try {
			NodeRef nodeRef = new NodeRef(nodeRefParam);
			boolean agentViewed = false;
			boolean customerViewed = false;
			boolean allViewed = false;

			Serializable hasAgentViewed = nodeService.getProperty(nodeRef, ManulifeContentModel.PROP_HAS_AGENT_VIEWED);
			if (hasAgentViewed != null && (boolean) hasAgentViewed) {
				agentViewed = true;
			} 
			model.put(BusinessConstants.PARAMETER_TYPE_AGENT, agentViewed);
			
			Serializable hasCustomerViewed = nodeService.getProperty(nodeRef,
					ManulifeContentModel.PROP_HAS_CUSTOMER_VIEWED);
			if (hasCustomerViewed != null && (boolean) hasCustomerViewed) {
				customerViewed = true;
			} 
			model.put(BusinessConstants.PARAMETER_TYPE_CUSTOMER, customerViewed);
			
			if(agentViewed && customerViewed){
				allViewed = true;
			}
			model.put(BusinessConstants.PREVIEW_STATUS_ALL_VIEWED, allViewed);

		} catch (Exception e) {
			logger.error(e.getMessage(), e);
			model.put(BusinessConstants.ERROR, e);
		}
		logger.debug(" ::: End DocumentPreviewStatusWebScript.executeImpl method ::: ");
		return model;
	}

	public void setNodeService(NodeService nodeService) {
		this.nodeService = nodeService;
	}
}