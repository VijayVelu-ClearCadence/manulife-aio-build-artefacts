package com.manulife.web.scripts.externalshare;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Base64;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import org.alfresco.repo.web.scripts.WebScriptUtil;
import org.alfresco.repo.web.scripts.quickshare.AbstractQuickShareContent;
import org.alfresco.service.cmr.quickshare.QuickShareDTO;
import org.alfresco.service.cmr.repository.InvalidNodeRefException;
import org.alfresco.service.cmr.repository.NodeRef;
import org.alfresco.service.cmr.repository.NodeService;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.extensions.webscripts.Cache;
import org.springframework.extensions.webscripts.Status;
import org.springframework.extensions.webscripts.WebScriptException;
import org.springframework.extensions.webscripts.WebScriptRequest;

import com.ibm.icu.impl.LinkedHashMap;
import com.manulife.constants.ManulifeContentModel;
import com.manulife.exceptions.MissingPropertiesException;
import com.sun.mail.smtp.SMTPTransport;

public class JHMLShareContentPost extends AbstractQuickShareContent {

	private static Log logger = LogFactory.getLog(JHMLShareContentPost.class);

	protected Properties properties;

	protected NodeService nodeService;

	public Properties getProperties() {
		return properties;
	}

	public void setProperties(Properties properties) {
		this.properties = properties;
	}

	public NodeService getNodeService() {
		return nodeService;
	}

	public void setNodeService(NodeService nodeService) {
		this.nodeService = nodeService;
	}

	@Override
	protected Map<String, Object> executeImpl(WebScriptRequest req, Status status, Cache cache) {

		logger.debug(" ::: Start JHMLShareContentPost ::: ");

		String agentLink = "";
		String customerLink = "";

		if (!isEnabled()) {
			throw new WebScriptException(403, "QuickShare is disabled system-wide");
		}

		Map<String, String> params = req.getServiceMatch().getTemplateVars();
		NodeRef nodeRef = WebScriptUtil.getNodeRef(params);

		logger.debug(" ::: nodeRef::: " + nodeRef);

		if (nodeRef == null) {

			String msg = "A valid NodeRef must be specified!";
			throw new WebScriptException(400, msg);
		}

		try {
			QuickShareDTO dto = this.quickShareService.shareContent(nodeRef);

			Map<String, Object> model = new HashMap<>(1);
			model.put("sharedDTO", dto);

			String webShareUrl = (String) properties.get("web.acs.share.url");
			String sharedId = dto.getId();

			if (webShareUrl == null || webShareUrl.isEmpty()) {
				throw new MissingPropertiesException(
						"web.acs.share.url property is not set properly in alfresco-global.properties.");
			}

			String encodedAgent = Base64.getEncoder().encodeToString("agent".getBytes());
			String encodedCustomer = Base64.getEncoder().encodeToString("customer".getBytes());

			agentLink = webShareUrl + "/s/" + sharedId + "?type=" + encodedAgent;
			customerLink = webShareUrl + "/s/" + sharedId + "?type=" + encodedCustomer;

			logger.debug(" ::: agentLink ::: " + agentLink);
			logger.debug(" ::: customerLink ::: " + customerLink);

			// send Email to Agent and Customer
			boolean mailsSent = sendEmails(nodeRef, agentLink, customerLink);
			model.put("mailsSent", mailsSent);

			logger.debug(" ::: End JHMLShareContentPost ::: ");

			return model;
		} catch (InvalidNodeRefException inre) {

			throw new WebScriptException(404, "Unable to find node: " + nodeRef);
		} catch (MissingPropertiesException mpe) {
			logger.error(mpe.getMessage(), mpe);
			return null;
		}
	}

	@SuppressWarnings("unchecked")
	private boolean sendEmails(NodeRef documentNodeRef, String agentLink, String customerLink) {

		boolean mailsSent = false;

		try {

			String agentEmail = (String) nodeService.getProperty(documentNodeRef,
					ManulifeContentModel.PROP_AGENT_EMAIL);
			String customerEmail = (String) nodeService.getProperty(documentNodeRef,
					ManulifeContentModel.PROP_CUSTOMER_EMAIL);
			logger.debug(" ::: agentEmail ::: " + agentEmail);
			logger.debug(" ::: customerEmail ::: " + customerEmail);

			// List<String> toList = new ArrayList<>();
			LinkedHashMap linkedHashMap = new LinkedHashMap();

			if (agentEmail != null && !agentEmail.isEmpty()) {
				// toList.add(agentEmail);
				linkedHashMap.put(agentEmail, agentLink);
			}
			if (customerEmail != null && !customerEmail.isEmpty()) {
				// toList.add(customerEmail);
				linkedHashMap.put(customerEmail, customerLink);
			}

			logger.debug(" ::: Share link Email linkedHashMap.toString() ::: " + linkedHashMap.toString());

			String smtpServerHost = (String) properties.get("mail.host");
			String smtpServerPort = (String) properties.get("mail.port");
			// String smtpServerProtocol = (String)
			// properties.get("mail.protocol");
			String smtpMailAuth = (String) properties.get("mail.smtp.auth");
			// String smtpUsername = (String) properties.get("mail.username");
			// String smtpPassword = (String) properties.get("mail.password");
			String emailFrom = (String) properties.get("mail.from.default");

			if (smtpServerHost == null || smtpServerHost.isEmpty()) {
				throw new MissingPropertiesException(
						"SMTP Property /'mail.host/' property is not set properly in alfresco-global.properties.");
			}

			Properties props = new Properties();
			props.put("mail.smtp.host", smtpServerHost);
			props.put("mail.smtp.socketFactory.port", smtpServerPort);
			props.put("mail.smtp.socketFactory.class", "javax.net.ssl.SSLSocketFactory");
			props.put("mail.smtp.auth", smtpMailAuth);
			props.put("mail.smtp.port", smtpServerPort);

			Session session = Session.getInstance(props, null);
			Message msg = new MimeMessage(session);

			Set<String> keys = linkedHashMap.keySet();

			for (String k : keys) {
				logger.debug(" ::: Iterating linkedHashMap keys ::: " + k + " -- " + linkedHashMap.get(k));

				msg.setFrom(new InternetAddress(emailFrom));
				msg.setRecipients(Message.RecipientType.TO, InternetAddress.parse(k, false));

				msg.setSubject("Email Link:");

				// String htmlString = agentLink + " <br> AND <br>" +
				// customerLink;
				String htmlString = linkedHashMap.get(k).toString();

				// HTML email
				msg.setDataHandler(new DataHandler(new HTMLDataSource(htmlString)));

				// SMTPTransport t = (SMTPTransport)
				// session.getTransport(smtpServerProtocol);
				SMTPTransport t = (SMTPTransport) session.getTransport();

				// connect
				// t.connect(smtpServerHost, smtpUsername, smtpPassword);
				t.connect();

				// send
				t.sendMessage(msg, msg.getAllRecipients());

				logger.debug("Response: " + t.getLastServerResponse());

				t.close();
			}

			mailsSent = true;

		} catch (MissingPropertiesException mpe) {
			mpe.printStackTrace();
			logger.error(mpe.getMessage(), mpe);
		} catch (MessagingException me) {
			me.printStackTrace();
			logger.error(me.getMessage(), me);
		}

		return mailsSent;

	}

	static class HTMLDataSource implements DataSource {

		private String html;

		public HTMLDataSource(String htmlString) {
			html = htmlString;
		}

		@Override
		public InputStream getInputStream() throws IOException {
			if (html == null)
				throw new IOException("html message is null!");
			return new ByteArrayInputStream(html.getBytes());
		}

		@Override
		public OutputStream getOutputStream() throws IOException {
			throw new IOException("This DataHandler cannot write HTML");
		}

		@Override
		public String getContentType() {
			return "text/html";
		}

		@Override
		public String getName() {
			return "HTMLDataSource";
		}
	}
}
